import AppWrapper from "../app-wrapper"

export default function Page() {
  return <AppWrapper />
}
