# Todo App
My todo app using nextjs tailwind css & shadcn UI design patterns
